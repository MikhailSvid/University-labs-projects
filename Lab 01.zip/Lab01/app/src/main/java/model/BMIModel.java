package model;

import static java.lang.String.format;

public class BMIModel {
    public static double getBMI(double weight, double height){
        double BMI = weight/(Math.pow(height, 2));
        return BMI;
    }

    public static double toDouble(String s){
        double str = Double.parseDouble(s);
        return str;
    }

    public static String formatBMI(double bmi){
       String strBMI = String.format("%.2f", bmi);
       return strBMI;
    }
}
