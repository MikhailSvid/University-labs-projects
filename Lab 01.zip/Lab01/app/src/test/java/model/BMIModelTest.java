package model;

import org.junit.Test;

public class BMIModelTest {
    @Test
    public void getBMITest(){
        double h, w;
        w = 60; h = 1.85;
        System.out.println("Testing BMIModel.getBMI()");
        System.out.println(w+" "+h);
        System.out.println(BMIModel.getBMI(w,h));
    }

    @Test
    public void toDoubleTest() {
        String str1, str2, str3;

        str1 = "23.056789";
        str2 = "5.98987";
        str3 = "0.1234";

        System.out.println("Testing BMIModel.toDouble()");
        System.out.println(str1 + " " + str2 + " " + str3);
        System.out.println(BMIModel.toDouble(str1));
        System.out.println(BMIModel.toDouble(str2));
        System.out.println(BMIModel.toDouble(str3));
    }

    @Test
    public void formatBMITest(){
        double num1,num2,num3;
        System.out.println("Testing BMIModel.formatBMI()");
        num1 = 18.5 + 35.0 * Math.random();
        num2 = 18.5 + 35.0 * Math.random();
        num3 = 18.5 + 35.0 * Math.random();

        System.out.println(num1 + " " + num2 + " " + num3);
        System.out.println(BMIModel.formatBMI(num1));
        System.out.println(BMIModel.formatBMI(num2));
        System.out.println(BMIModel.formatBMI(num3));
    }
}
