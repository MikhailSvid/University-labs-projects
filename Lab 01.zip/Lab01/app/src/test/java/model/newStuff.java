package model;

import android.view.View;

public class newStuff {

    public void buttonClicked(View v){}
}
